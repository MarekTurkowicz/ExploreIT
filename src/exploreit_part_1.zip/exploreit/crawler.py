"""The crawl loop: fetch pages, extract links and record the link graph."""

import time
from collections.abc import Callable
from pathlib import Path
from typing import Self

from pydantic import BaseModel, Field

from exploreit.config import CrawlConfig
from exploreit.content import extract_content
from exploreit.fetcher import Fetcher, FetchError
from exploreit.frontier import Frontier
from exploreit.models import CrawledPage, Edge, PageContent
from exploreit.parser import extract_links
from exploreit.urls import is_in_scope


class CrawlResult(BaseModel):
    """Everything a crawl produced: visited pages, links between them and failures.

    Page content is collected only when the config asks for it.
    """

    config: CrawlConfig
    pages: list[CrawledPage]
    edges: list[Edge]
    failed: dict[str, str]
    contents: list[PageContent] = Field(default_factory=list)
    duration: float = 0.0  # seconds the crawl took
    stopped: bool = False  # True if the user stopped the crawl before it finished

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.model_dump_json(indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> Self:
        return cls.model_validate_json(path.read_text(encoding="utf-8"))


def crawl(
    config: CrawlConfig,
    on_page: Callable[[CrawledPage], object] = lambda _: None,
    should_stop: Callable[[], bool] = lambda: False,
) -> CrawlResult:
    """Crawl from the start URL until the frontier is empty or max_pages is reached.

    Every link found on a visited page becomes an edge, including links that lead
    outside the scope. Only in-scope links within max_depth are visited.
    `should_stop` is checked before every page; when it returns True the crawl ends
    early and returns what it has collected so far.
    """
    started = time.monotonic()
    frontier = Frontier(config.strategy)
    frontier.add(config.start_url, depth=0)
    pages: list[CrawledPage] = []
    edges: list[Edge] = []
    failed: dict[str, str] = {}
    contents: list[PageContent] = []
    stopped = False

    with Fetcher(
        delay=config.delay, timeout=config.timeout, respect_robots=config.respect_robots
    ) as fetcher:
        while frontier and len(pages) < config.max_pages:
            if should_stop():
                stopped = True
                break
            url, depth = frontier.pop()
            try:
                page = fetcher.fetch(url)
            except FetchError as error:
                failed[url] = str(error)
                continue
            if depth == 0 and page.url != url:
                # The start page redirected, e.g. http://site to https://www.site/.
                # Crawl from where the site really is, so the scope check matches its links.
                url = page.url
                config = config.model_copy(update={"start_url": url})
                frontier.mark_seen(url)

            crawled = CrawledPage(
                url=url,
                depth=depth,
                status_code=page.status_code,
                content_type=page.content_type,
            )
            pages.append(crawled)
            on_page(crawled)

            if not page.html:
                continue
            if config.store_content:
                contents.append(extract_content(page.html, url))
            for link in extract_links(page.html, page.url, config.link_mode):
                if link.url in (url, page.url):
                    continue  # a link to the page itself, e.g. "#top", is not an edge
                edges.append(Edge(source=url, target=link.url, kind=link.kind))
                if depth < config.max_depth and is_in_scope(
                    link.url, config.start_url, config.scope
                ):
                    frontier.add(link.url, depth + 1)

    return CrawlResult(
        config=config,
        pages=pages,
        edges=edges,
        failed=failed,
        contents=contents,
        duration=time.monotonic() - started,
        stopped=stopped,
    )
